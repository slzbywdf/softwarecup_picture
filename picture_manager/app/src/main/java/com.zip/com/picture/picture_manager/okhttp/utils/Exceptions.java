package com.picture.picture_manager.okhttp.utils;

/**
 * Created by zhy on 15/12/14.
 */
public class Exceptions
{
    public static void illegalArgument(String msg)
    {
        throw new IllegalArgumentException(msg);
    }

}
